<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Apeal;

class ApealConroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $hname= $request ->input('student');
        $bedNo = $request -> input('e_hostel');
        $roomNo = $request -> input('e_bed');
        $gender = $request -> input('e_room');
        $stuYear = $request -> input('apply_reason');

        $hostel = new Apeal();
        $hostel -> student_id = $hname;
        $hostel -> e_hostel =$bedNo;
        $hostel -> e_bed =$roomNo;
        $hostel -> e_room =$gender;
        $hostel -> apply_reason =$stuYear;

        $hostel -> save();
        return redirect ('student.pag.appeal');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
