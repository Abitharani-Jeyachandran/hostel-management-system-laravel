
<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <ol class="d-flex breadcrumb bg-transparent p-0 justify-content-end">
            <li class="breadcrumb-item text-capitalize"><a href="/warden/home">Home</a></li>
            <li class="breadcrumb-item text-capitalizeactive" aria-current="page"><a href="<?php echo e(route('warden.students.index')); ?>">Students</a></li>
        </ol>
    </div>
</div>
<section class="content">
    <div class="container-fluid">
        <div class="container">
            <main class="mx-auto m-4">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4>Students List</h4>
                                    </div>
                                    <div>
                                        <a href="<?php echo e(route('warden.students.create')); ?>" class="btn btn-sm btn-primary float-end">Add Student</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table table-sm table-bordered border-primary">
                                    <thead>
                                    <tr>
                                        <th style="width: 20%">Enrollment Number</th>
                                        <th style="width: 20%">Email</th>
                                        <th style="width: 20%">First Name</th>
                                        <th style="width: 20%">Last Name</th>
                                        
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td ><?php echo e($student->enrollment_number); ?></td>
                                            <td><?php echo e($student->email); ?></td>
                                            <td ><?php echo e($student->firstname); ?></td>
                                            <td ><?php echo e($student->lastname); ?></td>
                                            
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="float-right">
                                    <?php echo e($data->links('pagination::bootstrap-4')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function deleteConfirmation(id){
        Swal.fire({
            title: 'Are you sure?',
            html: "You want to delete this record" ,
            icon:  'error',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: "Yes, Delete it!"
        }).then((result) => {
            if (result.isConfirmed) {
            $('#form-data-'+id).submit();
            }
        })
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('warden.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\selva\Desktop\New folder (2)\New folder (2)\hostel-management-system-laravel\hostel-management-system\resources\views/warden/pages/students/index.blade.php ENDPATH**/ ?>