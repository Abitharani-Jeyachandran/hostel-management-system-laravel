@extends('sub-warden.layouts.main')
@section('content')
hello sub warden
@endsection

@push('scripts')
@endpush
