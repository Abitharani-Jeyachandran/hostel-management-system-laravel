
<?php $__env->startSection('content'); ?>
hello <?php echo e(Auth::user()->firstname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('student.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\selva\Desktop\New folder (2)\New folder (2)\hostel-management-system-laravel\hostel-management-system\resources\views/student/pages/home.blade.php ENDPATH**/ ?>