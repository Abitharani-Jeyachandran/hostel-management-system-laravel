<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('apeals', function (Blueprint $table) {
            $table->id();
            $table->string('student_id')->default('CST18007');
            $table->string('e_hostel');
            $table->string('e_bed');
            $table->string('e_room');
            $table->string('apply_reason');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('apeals');
    }
};
